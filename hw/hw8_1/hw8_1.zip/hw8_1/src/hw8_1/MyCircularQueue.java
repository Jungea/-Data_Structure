package hw8_1;

public class MyCircularQueue {
	int[] a;
	int size;
	int num;
	int front;
	int rear;

	public MyCircularQueue(int size) {
		this.size = size;
		a = new int[size];
		num = 0;
		front = -1;
		rear = -1;
	}
}
