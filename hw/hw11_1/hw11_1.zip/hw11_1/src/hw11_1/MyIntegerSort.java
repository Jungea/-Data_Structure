package hw11_1;

public class MyIntegerSort {

	public static void mergeSort(int[] a) {

	}

	public static void mergeSort(int[] a, int lb, int ub) {

	}

	public static void merge(int[] a, int lb, int middle, int ub) {

	}
}
